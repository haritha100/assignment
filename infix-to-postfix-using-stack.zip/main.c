#include<stdio.h>
char stack[20];
int top = -1;
void push(char a)
{
    stack[++top] = a;
}
 
char pop()
{
    if(top == -1)
        return -1;
    else
        return stack[top--];
}
 
int importance(char a)
{
    if(a == '(')
        return 0;
    if(a == '+' || a == '-')
        return 1;
    if(a == '*' || a == '/')
        return 2;
}
 
main()
{
    char exp[20];
    char *e, a;
    printf("Enter the infix expression :: ");
    scanf("%s",exp);
    e = exp;                       //represents exponential value//
    while(*e != '\0')                   // '\0'indicate the termination of a character string.//
    {
        if(isalnum(*e))              /// *isalnum checks whether the given character is alphanumeric or not*///
            printf("%c",*e);
        else if(*e == '(')
            push(*e);
        else if(*e == ')')
        {
            while((a = pop()) != '(')
                printf("%c", a);
        }
        else
        {
            while(importance(stack[top]) >= importance(*e))
                printf("%c",pop());
            push(*e);
        }
        e++;
    }
    while(top != -1)
    {   
        printf("%c",pop());
    }
}