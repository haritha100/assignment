# include <stdio.h>
# include <malloc.h>

struct node
{
	int info;
	struct node *left_child;
	struct node *right_child;
}*root;



void find(int item,struct node **par,struct node **loc)
{
	struct node *ptr,*ptrsave;

	if(root==NULL)  /*tree empty*/
	{
		*loc=NULL;
		*par=NULL;
		return;
	}
	if(item==root->info) /*item is at root*/
	{
		*loc=root;
		*par=NULL;
		return;
	}
	                      /*Initialize ptr and ptrsave*/
	if(item<root->info)
		ptr=root->left_child;
	else
		ptr=root->right_child;
	ptrsave=root;

	while(ptr!=NULL)
	{
		if(item==ptr->info)
		{       *loc=ptr;
			*par=ptrsave;
			return;
		}
		ptrsave=ptr;
		if(item<ptr->info)
			ptr=ptr->left_child;
		else
			ptr=ptr->right_child;
	 }                                 
	 *loc=NULL;                        /*if item not found*/
	 *par=ptrsave;
}

void insert(int item)
{       struct node *tmp,*parent,*location;
	find(item,&parent,&location);
	if(location!=NULL)
	{
		printf("Item already present");
		return;
	}

	tmp=(struct node *)malloc(sizeof(struct node));
	tmp->info=item;
	tmp->left_child=NULL;
	tmp->right_child=NULL;

	if(parent==NULL)
		root=tmp;
	else
		if(item<parent->info)
			parent->left_child=tmp;
		else
			parent->right_child=tmp;
}


void case_a(struct node *par,struct node *loc )
{
	if(par==NULL)                        /*item to be deleted is root node*/
		root=NULL;
	else
		if(loc==par->left_child)
			par->left_child=NULL;
		else
			par->right_child=NULL;
}

void case_b(struct node *par,struct node *loc)
{
	struct node *child;

	/*Initialize child*/
	if(loc->left_child!=NULL) /*item to be deleted has leftchild */
		child=loc->left_child;
	else                /*item to be deleted has rightchild */
		child=loc->right_child;

	if(par==NULL )   /*Item to be deleted is root node*/
		root=child;
	else
		if( loc==par->left_child)   /*item is leftchild of its parent*/
			par->left_child=child;
		else                  /*item is rightchild of its parent*/
			par->right_child=child;
}

void case_c(struct node *par,struct node *loc)
{
	struct node *ptr,*ptrsave,*suc,*parsuc;
	                           /*Find inorder successor and its parent*/
	ptrsave=loc;
	ptr=loc->right_child;
	while(ptr->left_child!=NULL)
	{
		ptrsave=ptr;
		ptr=ptr->left_child;
	}
	suc=ptr;
	parsuc=ptrsave;

	if(suc->left_child==NULL && suc->right_child==NULL)
		case_a(parsuc,suc);
	else
		case_b(parsuc,suc);

	if(par==NULL) /*if item to be deleted is root node */
		root=suc;
	else
		if(loc==par->left_child)
			par->left_child=suc;
		else
			par->right_child=suc;

	suc->left_child=loc->left_child;
	suc->right_child=loc->right_child;
}
int del(int item)
{
	struct node *parent,*location;
	if(root==NULL)
	{
		printf("Tree empty");
		return 0;
	}

	find(item,&parent,&location);
	if(location==NULL)
	{
		printf("Item not present in tree");
		return 0;
	}

	if(location->left_child==NULL && location->right_child==NULL)
		case_a(parent,location);
	if(location->left_child!=NULL && location->right_child==NULL)
		case_b(parent,location);
	if(location->left_child==NULL && location->right_child!=NULL)
		case_b(parent,location);
	if(location->left_child!=NULL && location->right_child!=NULL)
		case_c(parent,location);
	free(location);
}/*End of del()*/

void display(struct node *ptr,int level)
{
	int i;
	if ( ptr!=NULL )
	{
		display(ptr->right_child, level+1);
		printf("\n");
		for (i = 0; i < level; i++)
			printf("    ");
		printf("%d", ptr->info);
		display(ptr->left_child, level+1);
	}/*End of if*/
}/*End of display()*/
main()
{
	int choice,num;
	root=NULL;
	while(1)
	{
		printf("\n");
		printf("1.Insert\n");
		printf("2.Delete\n");
		printf("3.Display\n");
		printf("4.Quit\n");
		printf("Enter your choice : ");
		scanf("%d",&choice);

		switch(choice)
		{
		 case 1:
			printf("Enter the number to be inserted : ");
			scanf("%d",&num);
			insert(num);
			break;
		 case 2:
			printf("Enter the number to be deleted : ");
			scanf("%d",&num);
			del(num);
			break;
		 case 3:
			display(root,1);
			break;
		 case 4:
            break;
		 default:
			printf("Wrong choice\n");
		}                               /*End of switch */
	}                                  /*End of while */
}                                            /*End of main()*/